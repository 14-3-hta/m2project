from django.apps import AppConfig


class HomilyConfig(AppConfig):
    name = 'homily'
