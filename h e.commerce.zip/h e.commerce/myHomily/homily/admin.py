from django.contrib import admin
from homily.models import CategoryModel, PostModel

# Register your models here

admin.site.register(CategoryModel)
admin.site.register(PostModel)