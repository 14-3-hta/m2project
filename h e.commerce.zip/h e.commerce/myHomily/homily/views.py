from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q 
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required, permission_required
from datetime import datetime
from django.contrib import messages
from homily.models import CategoryModel, PostModel
from django.contrib.auth.hashers import make_password

from django.conf import settings
from django.core.mail import send_mail

from django.template.loader import render_to_string
from django.utils.html import strip_tags

# Create your views here.

def Home(request):
    return redirect('/homily/post_list/')

def AddCategory(request):
    if request.method == "GET":
        return render(request, "add_category.html")
    if request.method == "POST":
        category = CategoryModel.objects.create(
            name = request.POST.get('name'),
        )
        category.save()
        messages.success(request, "New category is added successfully!")
        return redirect('/homily/view_category/')
    
def ViewCategory(request):
    category = CategoryModel.objects.all()
    return render(request, "view_category.html", {'category': category})

def EditCategory(request, category_id):
    if request.method == "GET":
        category = CategoryModel.objects.get(id = category_id)
        return render(request, "edit_category.html", {'category': category})
    if request.method == "POST":
        category = CategoryModel.objects.get(id = category_id)
        category.name = request.POST.get('name')
        category.save()
        messages.success(request, "Category is updated successfully!")
        return redirect('/homily/view_category/')

def DeleteCategory(request, category_id):
    category = CategoryModel.objects.get(id = category_id)
    category.delete()
    messages.error(request, "Category is deleted successfully!") 
    return redirect('/homily/view_category/')

def PostCreate(request):
    if request.method == "GET":
        category = CategoryModel.objects.all()
        return render(request, 'post_create.html', {"category": category})
    if request.method == "POST":
        category = CategoryModel.objects.all()
        post = PostModel.objects.create(
            title = request.POST.get('title'),
            content = request.POST.get('content'),
            image = request.FILES.get('image'),
            category_id = request.POST.get('category'),
            created_at = datetime.now(),
        )
        post.save()
        messages.success(request, "New post is created successfully!")
        return redirect('/homily/post_list/')
    
def PostList(request):
    post = PostModel.objects.all().order_by('-created_at')
    return render(request, 'post_list.html', {"post": post})

def PostDetail(request, post_id):
    post = PostModel.objects.get(id = post_id)
    return render(request, 'post_detail.html', {"post": post})

def PostUpdate(request, post_id):
    if request.method == "GET":
        category = CategoryModel.objects.all()
        post = PostModel.objects.get(id = post_id)
        return render(request, "post_update.html", {"post": post, "category": category})
    if request.method == "POST":
        category = CategoryModel.objects.all()
        post = PostModel.objects.get(id = post_id)
        post.title = request.POST.get('title')
        post.content = request.POST.get('content')
        post.category_id = request.POST.get('category')
        post.save()
        messages.success(request, "Post is updated successfully!")
        return redirect('homily/post_list/')
    
def PostDelete(request, post_id):
    post = PostModel.objects.get(id = post_id)
    post.delete()
    messages.error(request, "Post is deleted successfully!")
    return redirect('homily/post_list/')

def Login(request):
    if request.method == "GET":
        return render(request, 'login.html')
    if request.method == "POST":
        username = request.POST.get('username')        
        password = request.POST.get('password')
        try:
            user = User.objects.get(Q(email=username) | Q(username=username))
        except Exception:
            messages.error(request, 'Email or Password is incorrect!')
            return redirect('/login')
    else:
        if user.check_password(password):
            login(request, user)
            messages.success(request, 'Login Success!')
            return redirect('/homily/list')
        else:
            messages.error(request, 'Email or Password is incorrect!')
            return redirect('/login')
        
def Logout(request):
    messages.success(request, 'Logout Successfully!')
    return redirect('/homily/list')

def Register(request):
    if request.method == "GET":
        return render(request, 'register.html')
    if request.method =="POST":
        pw1 = request.POST.get('password')
        pw2 = request.POST.get('confirmpassword')
        username = request.POST. get('username')
        email = request.POST.get('email')
        if pw1 == pw2:
            if User.objects.filter(username=username):
                messages.error(request, 'Username already excist!')
                return redirect('/register')
            if User.objects.filter(email=email):
                messages.error(request, 'Email already excists!')
                return redirect('/register')
            user = User.objects.create(
                username = request.POST.get('username'),
                email = request.POST.get('email'),
                password = make_password('pw1')              
            )
            login(request, user)

            subject = 'Welcome to Django'            
            message = f'Hi {user.username}, thank you!'
            email_from = settings.EMAIL_HOST_USER
            recipient_list = [user.email, ]
            send_mail( subject, message, email_from, recipient_list)

            messages.success(request, "Register Success!")
            return redirect('/homily/list')
        else:
            messages.error(request, "Password is incorrect!")
            return redirect('/register')

def search_by(request):
            search = request.GET.get('search')
            if search:
                posts = PostModel.objects.filter(
                    Q(title_icontains=search) |
                    Q(choice_icontains=search)
                )
                return render(redirect, 'post_list.html', {'posts': posts})
            else:
                posts = PostModel.objects.all().order_by('created_at')
                return render(request, 'post_list.html', {'posts': posts})
            
def login_view(request):
    if request.method == "GET":
        return render(request,'login.html')
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)

            subject = 'welcome to Django'
            html_message = render_to_string('login.html')
            message = strip_tags(html_message)
            message = 'Hi Mg Mg, thank you'
            email_from = settings.EMAIL_HOST_USER
            recipient_list = ['mgmg@gmail.com', ]
            send_mail( subject, message, email_from, recipient_list)

            messages.info(request, "Login successfully.")
            return redirect('post_list')
        else:
            messages.error(request, "Username or Password is incorrect!")
            return redirect('login')
        
def logout_view(request):
    logout(request)
    return redirect('login')